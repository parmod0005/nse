
import streamlit as st
import numpy as np
import pandas as pd
import yfinance as yf
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from datetime import datetime

st.set_page_config(page_title="NSE/BSE Call/Put Predictor", layout="centered")
st.title("📈 NSE/BSE CALL/PUT Predictor (On-the-Fly LSTM)")
st.markdown("Real-time prediction model trained on last 60 days data from Yahoo Finance.")

# ------------------- Load Data ----------------------
def load_data(symbol, interval):
    df = yf.download(symbol, period="60d", interval=interval)
    df.dropna(inplace=True)
    df['Returns'] = df['Close'].pct_change()
    df['EMA_20'] = df['Close'].ewm(span=20).mean()
    df['RSI_14'] = compute_rsi(df['Close'], 14)
    df.dropna(inplace=True)
    return df

def compute_rsi(series, period=14):
    delta = series.diff()
    gain = np.maximum(delta, 0)
    loss = -np.minimum(delta, 0)
    avg_gain = gain.rolling(window=period).mean()
    avg_loss = loss.rolling(window=period).mean()
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))

def create_sequences(df, feature_cols, target_col='Close', seq_len=60):
    data = df[feature_cols].values
    target = (df[target_col].shift(-1) > df[target_col]).astype(int).values
    X, y = [], []
    for i in range(len(data) - seq_len):
        X.append(data[i:i+seq_len])
        y.append(target[i+seq_len])
    return np.array(X), np.array(y)

def build_model(input_shape):
    model = Sequential()
    model.add(LSTM(64, return_sequences=True, input_shape=input_shape))
    model.add(Dropout(0.2))
    model.add(LSTM(64))
    model.add(Dropout(0.2))
    model.add(Dense(1, activation='sigmoid'))
    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    return model

# ------------------- User Input ----------------------
symbol_map = {
    "NIFTY 50": "^NSEI",
    "BANKNIFTY": "^NSEBANK",
    "FINNIFTY": "^CNXFIN"
}

symbol_label = st.selectbox("Select Index", list(symbol_map.keys()))
interval = st.selectbox("Select Timeframe", ["5m", "15m", "1h"])
predict_btn = st.button("🔮 Train & Predict")

if predict_btn:
    st.info("⏳ Loading data and training model...")
    df = load_data(symbol_map[symbol_label], interval)
    feature_cols = ['Close', 'EMA_20', 'RSI_14']
    scaler = MinMaxScaler()
    df[feature_cols] = scaler.fit_transform(df[feature_cols])
    X, y = create_sequences(df, feature_cols)

    if len(X) == 0:
        st.error("❌ Not enough data to train the model.")
    else:
        model = build_model((X.shape[1], X.shape[2]))
        model.fit(X, y, epochs=5, batch_size=32, verbose=0)
        last_seq = X[-1].reshape(1, X.shape[1], X.shape[2])
        pred = model.predict(last_seq)[0][0]
        label = "📗 BUY CALL" if pred > 0.6 else "📕 BUY PUT" if pred < 0.4 else "⚪ NO TRADE"

        st.success(f"Prediction: {label}")
        st.metric("Confidence", f"{round(pred*100, 2)}%")
        st.caption(f"Last trained on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
