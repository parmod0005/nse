---
title: NSE/BSE Call/Put Predictor
emoji: 📈
colorFrom: blue
colorTo: green
sdk: streamlit
sdk_version: "1.35.0"
app_file: app.py
pinned: false
---

# NSE/BSE Call/Put Predictor

🚀 Real-time options prediction app using LSTM and live Yahoo Finance data.

### ✅ Features:
- Trains an LSTM model on-the-fly using last 60 days of 5m/15m/1h data
- Predicts CALL / PUT / NO TRADE bias
- Visual UI using Streamlit
- Built for NIFTY, BANKNIFTY, FINNIFTY

### 🛠️ How to use:
1. Select symbol (NIFTY, BANKNIFTY, etc.)
2. Choose timeframe (5m, 15m, 1h)
3. Click “Train & Predict”
4. View the CALL/PUT decision and confidence score

### 🧠 Powered by:
- TensorFlow LSTM
- Streamlit
- Yahoo Finance API

---

Deployed on Hugging Face Spaces 💡