import os
os.system("streamlit run main.py")