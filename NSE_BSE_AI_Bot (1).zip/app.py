import streamlit as st
from main import *

# Entry point for deployment (Render/HF Spaces)
# Everything loads from main.py